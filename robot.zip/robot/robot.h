#ifndef Robot_h
#define Robot_h

#include <Arduino.h>

class Robot
{
public:
	Robot(); // Main class object
	void left_motor(int power);
	void right_motor(int power);	
};

#endif
