#include <Arduino.h>
#include "Robot.h"

Robot::Robot()
{
	#define motor1pin1 4 //left motor forwards
	#define motor1pin2 5 //left motor backwards
	#define motor2pin1 6 //right motor ...
	#define motor2pin2 7
	#define ENA 3 //left motor speed pin
	#define ENB 11 //right motor speed pin
	pinMode(motor1pin1, OUTPUT); // Sets motor pins to be OUTPUT
  	pinMode(motor1pin2, OUTPUT);
  	pinMode(motor2pin1, OUTPUT);
  	pinMode(motor2pin2, OUTPUT);
  	pinMode(ENA, OUTPUT); //speed pins to OUTPUT
  	pinMode(ENB, OUTPUT);
}

/** turn left motor at power speed (can be negative for backwards) */
void Robot::left_motor(int power){
  if(abs(power)>255) return;
  if(power < 0){//backwards
    power = abs(power);
    analogWrite(ENA, power);
    digitalWrite(motor1pin1, LOW);
    digitalWrite(motor1pin2, HIGH);
  }else{//forwards
    analogWrite(ENA, power);
    digitalWrite(motor1pin1, HIGH);
    digitalWrite(motor1pin2, LOW);
  } 
}

/** turn right motor at power speed (can be negative for backwards) */
void Robot::right_motor(int power){
  if(abs(power)>255) return;
  if(power < 0){//backwards
    power = abs(power);
    analogWrite(ENB, power);
    digitalWrite(motor2pin1, LOW);
    digitalWrite(motor2pin2, HIGH);
  }else{//forwards
    analogWrite(ENB, power);
    digitalWrite(motor2pin1, HIGH);
    digitalWrite(motor2pin2, LOW);
  } 
}
